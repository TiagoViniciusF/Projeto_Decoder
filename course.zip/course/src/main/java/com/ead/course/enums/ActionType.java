package com.ead.course.enums;

public enum ActionType {
    CREATE,
    UPDATE,
    DELETE;
}
