package com.ead.course.enums;

public enum CourseLevel {
    BEGINNER,
    INTERMEDIARY,
    ADVANCED;
}
